//#pragma once
//#include<vector>
//#include <SFML/Audio.hpp>
//#include <SFML/Graphics.hpp>
//
//using namespace sf;
//using namespace std;
//class Graphics;
//
//enum class Type {
//	Grpahics,
//	Sounds,
//};
//
//class ResourceMgr
//{
//private:
//	static vector<Graphics*> resourceGraphic;
//	vector<Sound*> resourceSound;
//	vector<Font*> resourceFont;
//public:
//	ResourceMgr();
//	~ResourceMgr();
//	static void PutResourceGraphic(Graphics* graphic);
//
//};
//
